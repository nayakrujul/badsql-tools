# badsql-tools
The badsql-tools library in Python
